PRAGMA foreign_keys = true;
drop table if exists half;
drop table if exists pause;
drop table if exists score;
drop table if exists user_ans;
drop table if exists questions;
drop table if exists subtopics;
drop table if exists topics;
drop table if exists users;

  CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT,
  name text not null,
  email text not null,
  username text not null,
  password text not null
);
create table topics(id INTEGER PRIMARY KEY AUTOINCREMENT,
name text not null
);
create table subtopics(id INTEGER PRIMARY KEY AUTOINCREMENT,
name text not null,
user_id int,
topic_id int,
foreign key(topic_id) REFERENCES topics(id) ON UPDATE CASCADE ON DELETE CASCADE,
foreign key(user_id) REFERENCES users(id) ON UPDATE CASCADE ON DELETE CASCADE
);
create table questions(id INTEGER PRIMARY KEY AUTOINCREMENT,
  name text not null,
  optionA text not null,
  optionB text not null,
  optionC text not null,
  optionD text not null,
  ans text not null,
  ty text not null,
  subtopic_id int,
  foreign key(subtopic_id) REFERENCES subtopics(id) ON UPDATE CASCADE ON DELETE CASCADE
);
create table user_ans(id INTEGER PRIMARY KEY AUTOINCREMENT,
  ans text not null,
  ques_id int,
  user_id int,
  foreign key(ques_id) REFERENCES questions(id) ON UPDATE  CASCADE ON DELETE CASCADE,
  foreign key(user_id) REFERENCES users(id) ON UPDATE CASCADE ON DELETE CASCADE
);
create table score(id INTEGER PRIMARY KEY AUTOINCREMENT,
  score int,
  subtopic_id int,
  user_id int,foreign key(subtopic_id) references subtopics(id) ON UPDATE  CASCADE ON DELETE CASCADE,
  foreign key(user_id) references users(id) ON UPDATE  CASCADE ON DELETE CASCADE
);
create table pause(id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id int,
subtopic_id int,
ques_id int,
foreign key(subtopic_id) REFERENCES subtopics(id) ON UPDATE  CASCADE ON DELETE CASCADE,
  foreign key(user_id) REFERENCES users(id) ON UPDATE CASCADE ON DELETE CASCADE
);
create table half(id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id int,
subtopic_id int,
count int,
foreign key(subtopic_id) REFERENCES subtopics(id) ON UPDATE  CASCADE ON DELETE CASCADE,
  foreign key(user_id) REFERENCES users(id) ON UPDATE CASCADE ON DELETE CASCADE
 )
