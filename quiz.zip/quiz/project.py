from flask import request,Flask,render_template,flash,redirect,url_for,session,logging
from wtforms import Form,StringField,TextAreaField,PasswordField,validators
from passlib.hash import sha256_crypt
import model
import sqlite3 as sql
from random import randint

gl = 0
app = Flask(__name__)
app.secret_key="surya"
#model.create()
app.debug=True
@app.route('/')
def start():
    return 'start';
@app.route('/AllUsers')
def allusers():
    rows,msg=model.getAll()
    return render_template('allusers.html',rows = rows,message=msg)
class RegisterForm(Form):
    name = StringField('Name', [validators.Length(min=1, max=25)])
    email = StringField('Email', [validators.Email()])
    username = StringField('Username', [validators.Length(min=3, max=25)])
    password = PasswordField('Password', [validators.DataRequired(),
    validators.EqualTo('confirm', message='Passwords do not match')])
    confirm = PasswordField('Confirm Password')
@app.route('/CreateAccount',methods=['GET', 'POST'])
def register():
    form = RegisterForm(request.form)
    if request.method == 'POST' and form.validate():
        name = form.name.data
        email = form.email.data
        username = form.username.data
        password = sha256_crypt.encrypt(str(form.password.data))
        with sql.connect("database.db") as con:
            con.row_factory = sql.Row
            cur = con.cursor()
            sqlQuery  = "select username from users where username = '" + username + "';"
            cur.execute(sqlQuery)
            row = cur.fetchone()
            print row
            if row:
                flash("User with username %s is already present,insertion failed!" %username,'danger')
            else:
                cur.execute("INSERT INTO users (name,email,username,password) VALUES (?,?,?,?)",(name,email,username,password))
                sqlQuery  = "select * from users where username = '" + username + "';"
                cur.execute(sqlQuery)
                user = cur.fetchone()
                user_id = user[0]
                cur.execute("select * from subtopics")
                sub = cur.fetchall()
                for quiz in sub:
                    if quiz['user_id'] == None:
                        cur.execute("INSERT INTO pause (user_id,subtopic_id,ques_id) VALUES (?,?,?)",(user_id,quiz['id'],1))
                        cur.execute("INSERT INTO half (subtopic_id,user_id,count) VALUES (?,?,?)",(quiz['id'],user_id,0))

                con.commit()
                cur.close()
                flash('You have a new account and you can login','success')
                return redirect(url_for('login'))
    return render_template('register1.html',form=form)
@app.route('/login',methods=['GET','POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        p_submited = request.form['password']
        if username and p_submited:
            with sql.connect("database.db") as con:
                cur = con.cursor()
                query = cur.execute("select * from users where username = '" + username + "';")
                check = cur.fetchone()
                if check:
                    print check
                    password = check[4]
                    if sha256_crypt.verify(p_submited,password):
                        session['logged_in'] = True
                        session['username'] = username
                        session['user_id'] = check[0]
                        print session['user_id']
                        return redirect(url_for('dashboarduser'))
                    else:
                        error = "password not matched"
                        return render_template('login.html',error = error)
                else:
                    error = "username does not exist"
                    return render_template('login.html',error = error)
        elif username:
            error = "please enter Password"
            return render_template('login.html',error = error)
        elif p_submited:
            error = "please enter Username"
            return render_template('login.html',error = error)
        else:
            error = "please fill details"
            return render_template('login.html',msg = error)
    return render_template('login.html')
@app.route('/dashboardadmin')
def dashboardadmin():
    if 'logged_in' in session:
        if session['username'] == 'adminps':
            flash('WELCOME ADMIN','success')
            return render_template('dashboardadmin.html')
        else:
            flash('ONLY ADMIN CAN LOGIN FROM THIS','danger')
            return redirect(url_for('admin'))
    else:
        flash('YOU CANNOT ACCESS THE REQUESTED  PAGE WITHOUT LOGGiNG IN AS ADMIN','danger')
        return redirect(url_for('admin'))
@app.route('/dashboarduser')
def dashboarduser():
    if 'logged_in' in session:
        if session['username'] != 'adminps':
            flash('YOU ARE LOGGED IN','success')
            topics,subtopics = model.getAll()
            with sql.connect("database.db") as con:
                con.row_factory = sql.Row
                cur = con.cursor()
                sqlQuer2  = "select * from users where username = '" + session['username'] + "';"
                print session['username']
                cur.execute(sqlQuer2)
                aaa = cur.fetchone()
                print aaa
                user_id= aaa[0]
                print user_id
                user_id = str(user_id)
                sqlQuer2  = "select * from score where user_id = '" + user_id + "';"
                cur.execute(sqlQuer2)
                aaa = cur.fetchall()
                none = None
                sqlQuer2  = "select * from subtopics ;"
                cur.execute(sqlQuer2)
                sub = cur.fetchall()
                q_id = {}
                for quiz in sub:
                    if quiz['user_id'] == None:
                        cur.execute("select * from pause where subtopic_id = '" + str(quiz['id']) + "' and user_id = '"  + str(user_id) + "';")
                        pauses = cur.fetchone()
                        if pauses !=None:
                            q_id[quiz['name']] = pauses[3]

                print q_id
                con.commit()
            return render_template('dashboard.html',topics = topics,subtopics = subtopics,user_id=user_id,score=aaa,q_id=q_id)
        else:
            flash('ONLY USER CAN LOGIN FROM THIS','danger')
            return redirect(url_for('login'))
    else:
        flash('YOU CANNOT ACCESS THE REQUESTED  PAGE WITHOUT LOGGING IN AS USER','danger')
        return redirect(url_for('login'))
@app.route('/logout')
def logout():
    session.clear()
    flash('YOU ARE LOGGED  OUT', 'success')
    return redirect(url_for('login'))
@app.route('/admin',methods=['GET','POST'])
def admin():
    print request.method
    #return redirect(url_for('login'))
    if request.method == 'POST':
        username = request.form['username']
        p_submited = request.form['password']
        if username and p_submited:
            with sql.connect("database.db") as con:
                cur = con.cursor()
                query = cur.execute("select * from users where username = '" + username + "';")
                check = cur.fetchone()
                if check:
                    print check
                    password = check[4]
                    if sha256_crypt.verify(p_submited,password):
                        session['logged_in'] = True
                        session['username'] = username
                        return redirect(url_for('dashboardadmin'))
                    else:
                        error = "password not matched"
                        return render_template('admin.html',error = error)
                else:
                    error = "AdminName does not exist"
                    return render_template('admin.html',error = error)
        elif username:
            error = "please enter Password"
            return render_template('admin.html',error = error)
        elif p_submited:
            error = "please enter Username"
            return render_template('admin.html',error = error)
        else:
            error = "please fill details"
            return render_template('admin.html',msg = error)
    return render_template('admin.html')
@app.route('/addquiz',methods=['GET','POST'])
def add():
    if 'logged_in' in session:
        if session['username'] == 'adminps':
            print request.method
            if request.method == 'POST':
                topic = request.form['topic']
                subtopic = request.form['subtopic']
                question = request.form['question']
                oa = request.form['oa']
                ob = request.form['ob']
                oc = request.form['oc']
                od = request.form['od']
                ans = ''
                try:
                    temp = request.form['a']
                    ans += 'A'
                except:
                    pass
                try:
                    temp = request.form['b']
                    ans += 'B'
                except:
                    pass
                try:
                    temp = request.form['c']
                    ans += 'C'
                except:
                    pass
                try:
                    temp = request.form['d']
                    ans += 'D'
                except:
                    pass
                try:
                    temp = request.form['sin']
                    ty = 's'
                except:
                    pass
                try:
                    temp = request.form['mul']
                    ty = 'm'
                except:
                    pass
                print topic,subtopic,ty,question,ans
                if topic and subtopic and question and ty and oa and ob and oc and od and ans:
                    with sql.connect("database.db") as con:
                        cur = con.cursor()
                        sqlQuer  = "select name from topics where name = '" + topic + "';"
                        cur.execute(sqlQuer)
                        ro = cur.fetchone()
                        print ro
                        if ro == None:
                            cur.execute("INSERT INTO topics (name) VALUES (?)",(topic,))
                            con.commit()
                            cur.close()
                    with sql.connect("database.db") as con:
                        cur = con.cursor()
                        sqlQuer  = "select * from topics where name = '" + topic + "';"
                        cur.execute(sqlQuer)
                        row = cur.fetchone()
                        sqlQuer1  = "select * from subtopics where name = '" + subtopic + "';"
                        cur.execute(sqlQuer1)
                        row1 = cur.fetchone()
                        print row,row1
                        f_id = row[0]
                        if row1 == None:
                            cur.execute("INSERT INTO subtopics (name,topic_id) VALUES(?,?)",(subtopic,f_id))
                        sqlQuer2  = "select * from subtopics where name = '" + subtopic + "';"
                        cur.execute(sqlQuer2)
                        row2 = cur.fetchone()
                        qu_id = row2[0]
                        print qu_id
                        cur.execute("INSERT INTO questions (name,optionA,optionB,optionC,optionD,ans,ty,subtopic_id) VALUES(?,?,?,?,?,?,?,?)",(question,oa,ob,oc,od,ans,ty,qu_id));
                        cur.execute("select * from users")
                        users = cur.fetchall()
                        for user in users:
                            sqlQuer = "select * from pause where subtopic_id = '" + str(qu_id) + "' and user_id = '"  + str(user[0]) + "';"
                            cur.execute(sqlQuer)
                            pauses = cur.fetchall()
                            if pauses == []:
                                cur.execute("INSERT INTO pause (subtopic_id,user_id,ques_id) VALUES(?,?,?)",(qu_id,user[0],1));
                            sqlQuer = "select * from half where subtopic_id = '" + str(qu_id) + "' and user_id = '"  + str(user[0]) + "';"
                            cur.execute(sqlQuer)
                            halves = cur.fetchall()
                            if halves == []:
                                cur.execute("INSERT INTO half (subtopic_id,user_id,count) VALUES(?,?,?)",(qu_id,user[0],0));
                        flash('YOUR QUESTION SAVED SUCCESSFULLY, SCROLL DOWN TO SELECT YOUR CHOICE','success')
                        con.commit()
                    return redirect(url_for('add'))
                else:
                    flash("PLEASE ENTER DETAILS CORRECTLY",'danger')
                    return render_template('addquiz.html')
                    #cur.execute("INSERT INTO questions (name,optionA,optionB,optionC,optionD,ty,subtopic_id) VALUES(?,?,?,?,?,?,?)",(question,oa,ob,oc,od,t,q_id))
            return render_template('addquiz.html')
    else:
        flash('YOU MUST BE LOGGED IN AS ADMIN TO DO THIS TASK','danger')
        return redirect(url_for('admin'))
    return render_template('addquiz.html')
@app.route('/showquiz')
def showquiz():
    if 'logged_in' in session and session['username'] == 'adminps':
        topics,subtopics = model.getAll()
        return render_template('quiz.html',topics = topics,subtopics = subtopics )
    else:
        flash('YOU MUST BE LOGGED IN AS ADMIN TO DO THIS TASK','danger')
        return redirect(url_for('admin'))
@app.route('/printf/<name>/<int:id>/<int:flag>',methods=['GET','POST'])
def printf(name,id,flag):
    if 'logged_in' in session:
            i_d = session['user_id']
            prev_score = 0
            prev_answer = ''
            flags = [0,0,0,0,0]

            with sql.connect('database.db') as con:
                con.row_factory = sql.Row
                cur = con.cursor()
                sqlQuer2  = "select * from subtopics where name = '" + name + "';"
                cur.execute(sqlQuer2)
                rows = cur.fetchall()
                name,t_id = rows[0]['name'],rows[0]['topic_id']
                cur.execute("INSERT INTO subtopics (name,user_id,topic_id) VALUES(?,?,?)",(name,i_d,t_id))
                req = rows[0]['id']
                req = str(req)
                i_d = str(i_d)
                sqlQuer = "select * from score where subtopic_id = '" + req + "' and user_id = '"  + i_d + "';"
                cur.execute(sqlQuer)
                scores = cur.fetchall()
                if len(scores) == 0:
                    print "wrong"
                    cur.execute("INSERT INTO score(score,subtopic_id,user_id) VALUES(?,?,?)",(0,req,i_d))
                sqlQuer = "select * from questions where subtopic_id = '" + req + "';"
                cur.execute(sqlQuer)
                row = cur.fetchall()
                r = row[id-1]
                ind=id
                answer = r['ans']
                q_ind = r['id']
                q_ind = str(q_ind)
                sqlQuer = "select * from user_ans where ques_id = '" + q_ind + "' and user_id = '"  + i_d + "';"
                cur.execute(sqlQuer)
                prev = cur.fetchall()
                sqlQuer = "select * from score where subtopic_id = '" + req + "' and user_id = '"  + i_d + "';"
                cur.execute(sqlQuer)
                prevs = cur.fetchall()
                prev_score = prevs[0]['score']
                if len(prev) != 0:
                    prev_answer = prev[0]['ans']
                print 'flag',flag*6
                if flag == 1:
                    print 'f',flag
                    if answer == 'A':
                        op = randint(2,4)
                        flags[1] = 1
                        flags[op] = 1
                    if answer == "B":
                        flags[2] = 1
                        flags[4] = 1
                    if answer == "C":
                        flags[3] = 1
                        flags[4] = 1
                    if answer == 'D':
                        op = randint(1,3)
                        flags[4] = 1
                        flags[op] = 1
                    print "if" ,flags
                if flag == 0:
                    print 'fl',flag
                    flags[3],flags[1],flags[2],flags[4]=1,1,1,1
                print flags





            if request.method == 'POST':
                ans = ''
                try:
                    temp = request.form['a']
                    ans += 'A'
                except:
                    pass
                try:
                    temp = request.form['b']
                    ans += 'B'
                except:
                    pass
                try:
                    temp = request.form['c']
                    ans += 'C'
                except:
                    pass
                try:
                    temp = request.form['d']
                    ans += 'D'
                except:
                    pass
                
                print prev_score,ans,answer
                if ans != '':
                    with sql.connect('database.db') as con:
                        cur = con.cursor()
                        if len(prev) == 0:
                            print len(prev)
                            cur.execute("INSERT INTO user_ans(ques_id,user_id,ans) VALUES(?,?,?)" ,(q_ind,i_d,ans))
                        else:
                            prev_answer = prev[0]['ans']
                            print req,i_d
                            print prev
                            cur.execute("UPDATE user_ans set ans = ? where ques_id = ? and user_id = ?",[ans,q_ind,i_d])
                        if ans == answer:
                            if prev_answer != answer:
                                prev_score += 1
                        else:
                            if prev_answer == answer and prev_score != 0:
                                prev_score -= 1
                    prev_answer = ans
                    print prev_score,req,i_d
                    cur.execute("select * from score where subtopic_id = ? and user_id = ?",[req,i_d])
                    print cur.fetchall()
                    print prev_score
                    cur.execute("UPDATE score set score = ? where subtopic_id = ? and user_id = ?",[prev_score,req,i_d])
                    cur.execute("select * from score where subtopic_id = ? and user_id = ?",[req,i_d])
                    print "after",cur.fetchall()
                    con.commit()
                if id < len(row):
                    return redirect(url_for('printf',name = name,id = id+1,flag=0))
            return render_template('qestion.html',flags = flags,qes=r,ind=ind,lent=len(row),name=name,score = prev_score,p = prev_answer,req = req,i_d = i_d)
    else:
        flash('YOU MUST BE LOGGED IN TO DO THIS TASK','danger')
        return redirect(url_for(login))
@app.route('/score/<req>/<i_d>')
def score(req,i_d):
    lists = []
    with sql.connect('database.db') as con:
        con.row_factory = sql.Row
        cur = con.cursor()
        sqlQuer = "select * from score where subtopic_id = '" + req + "' and user_id = '"  + i_d + "';"
        cur.execute(sqlQuer)
        scores = cur.fetchall()
        score = 0#scores[0]['score']
        print score
        cur.execute("select  * from score order by score DESC")
        sorted = cur.fetchall()
        print sorted[0][3],req
        for i in sorted:
            print i[2],req
            if int(i[2]) == int(req):
                print i
                u_id = i['user_id']
                u_id = str(u_id)
                print u_id
                sqlQuer = "select * from users where id = '" + u_id + "';"
                cur.execute(sqlQuer)
                use = cur.fetchall()
                username = use[0]['username']
                scores = i[1]
                lists.append((username,scores))
        print lists
        sqlQuer = "select * from score where subtopic_id = '" + req + "';"
        cur.execute(sqlQuer)
        leader = cur.fetchall()
        cur.execute("select * from users where id = '" + str(i_d) + "';")
        user = cur.fetchone()
        username  = user['username']
        con.commit()
    score = 0
    return render_template('score.html',score = score,lists = lists,username=username)
@app.route('/leader/<req>/<i_d>')
def leader(req,i_d):
    lists = []
    with sql.connect('database.db') as con:
        con.row_factory = sql.Row
        cur = con.cursor()
        sqlQuer = "select * from score where subtopic_id = '" + req + "' and user_id = '"  + i_d + "';"
        cur.execute(sqlQuer)
        scores = cur.fetchall()
        score = 0#scores[0]['score']
        print score
        cur.execute("select  * from score order by score DESC")
        sorted = cur.fetchall()
        for i in sorted:
            print i[2],req
            if int(i[2]) == int(req):
                print i
                u_id = i['user_id']
                u_id = str(u_id)
                print u_id
                sqlQuer = "select * from users where id = '" + u_id + "';"
                cur.execute(sqlQuer)
                use = cur.fetchall()
                username = use[0]['username']
                scores = i[1]
                lists.append((username,scores))
        print lists
        sqlQuer = "select * from score where subtopic_id = '" + req + "';"
        cur.execute(sqlQuer)
        leader = cur.fetchall()
        con.commit()
    score = 0
    return render_template('leader.html',score = score,lists = lists)

@app.route('/quizprint/<name>')
def quizprint(name):
    with sql.connect('database.db') as con:
        con.row_factory = sql.Row
        cur = con.cursor()
        sqlQuer2  = "select * from subtopics where name = '" + name + "';"
        cur.execute(sqlQuer2)
        quiz = cur.fetchone()
        print quiz
        sqlQuer2  = "select * from questions where subtopic_id = '" + str(quiz[0]) + "';"
        cur.execute(sqlQuer2)
        questions = cur.fetchall()
        print questions
        con.commit()
    return render_template('quizprint.html',ques=questions)
@app.route('/usersdata')
def userdata():
    with sql.connect('database.db') as con:
        con.row_factory = sql.Row
        cur = con.cursor()
        sqlQuer = "select * from users";
        cur.execute(sqlQuer)
        users = cur.fetchall()
        print users
        con.commit()
    return render_template('userdata.html',users=users)
@app.route('/attemptedquiz/<id>')
def attemptedquiz(id):
    lists = []
    with sql.connect('database.db') as con:
        con.row_factory = sql.Row
        cur = con.cursor()
        sqlQuer2  = "select * from subtopics where user_id = '" + id + "';"
        cur.execute(sqlQuer2)
        quiz = cur.fetchall()
        cur.execute("select * from subtopics")
        subtopics = cur.fetchall()
        f = {}
        print quiz
        for q in quiz:
            f[q['name']]=0
        for q in quiz:
            if f[q['name']] == 0:
                f[q['name']] = 1
                for i in subtopics:
                    if i['name'] == q['name']:
                        break
                print i
                q_id = i['id']
                print q
                sqlQuer = "select * from score where subtopic_id = '" + str(q_id) + "' and user_id = '"  + str(id) + "';"
                cur.execute(sqlQuer)
                scores = cur.fetchone()
                print scores
                lists.append((q['name'],scores['score']))
        print lists
        con.commit()
    return render_template('attemptedquiz.html',lists=lists)
@app.route('/pause/<user_id>/<quiz_id>/<q_id>')
def pause(user_id,quiz_id,q_id):
    with sql.connect('database.db') as con:
        con.row_factory = sql.Row
        cur = con.cursor()
        cur.execute("UPDATE pause set ques_id = ? where user_id = ? and subtopic_id = ?",[q_id,user_id,quiz_id])
        con.commit()
    return redirect(url_for('dashboarduser'))
@app.route('/half/<user_id>/<quiz_id>/<name>/<ind>')
def half(user_id,quiz_id,name,ind):
    with sql.connect('database.db') as con:
        con.row_factory = sql.Row
        cur = con.cursor()
        cur.execute("select count from half where user_id = '" + str(user_id) + "' and subtopic_id = '"  + str(quiz_id) + "';")
        count = cur.fetchone()
        print count
        if count[0] == 0:
            cur.execute("UPDATE half set count = ? where user_id = ? and subtopic_id = ?",[1,user_id,quiz_id])
            cur.execute("select count from half where user_id = '" + str(user_id) + "' and subtopic_id = '"  + str(quiz_id) + "';")
            print cur.fetchall()
            con.commit()
            return redirect(url_for('printf',name =  name,id = ind,flag=1))

        else:
            flash('Cannot use more than 1 time','danger')
            return redirect(url_for('printf',name =  name,id = ind,flag=0))


@app.route('/delete/<id>')
def delete(id):
    with sql.connect('database.db') as con:
        con.row_factory = sql.Row
        cur = con.cursor()
        cur.execute("delete from users where id = '" + str(id) + "';")
        cur.execute("delete from subtopics where user_id = '" + str(id) + "';")
        cur.execute("delete from score where user_id = '" + str(id) + "';")
        cur.execute("delete from pause where user_id = '" + str(id) + "';")
        cur.execute("delete from user_ans where user_id = '" + str(id) + "';")
        con.commit()

    return redirect(url_for('userdata'));
if __name__== '__main__':
    app.run()
