import sqlite3 as sql

def getAll():
  try:
    with sql.connect("database.db") as con:
      con.row_factory = sql.Row
      cur = con.cursor()
      cur.execute("select * from topics")
      rows = cur.fetchall()
      print rows
      for row in rows:
           print "row=" +  row["name"]
      cur.execute("select * from subtopics")
      msg = cur.fetchall()
      print msg

      return (rows,msg)
  except:
      print "connection failed"
      return ([], "connection failed")
def getquestions():
    try:
      with sql.connect('database.db') as con:
        con.row_factory = sql.row
        cur = con.cursor()
        cur.execute("select * from questions")
        qs = cur.fetchall()
        print qs
        return qs
    except:
        print "connection failed"
        return ([])
def score(req,i_d):
    try:
      with sql.connect('database.db') as con:
        con.row_factory = sql.Row
        cur = con.cursor()
        sqlQuer = "select * from score where subtopic_id = '" + req + "' and user_id = '"  + i_d + "';"
        cur.execute(sqlQuer)
        scores = cur.fetchall()
        score = 0#scores[0]['score']
        print score
        cur.execute("select  * from score order by score DESC")
        sorted = cur.fetchall()
        print sorted[0][3],req
        for i in sorted:
            print i[2],req
            if int(i[2]) == int(req):
                print i
                u_id = i['user_id']
                u_id = str(u_id)
                print u_id
                sqlQuer = "select * from users where id = '" + u_id + "';"
                cur.execute(sqlQuer)
                use = cur.fetchall()
                username = use[0]['username']
                scores = i[1]
                lists.append((username,scores))
                print lists
                sqlQuer = "select * from score where subtopic_id = '" + req + "';"
                cur.execute(sqlQuer)
                leader = cur.fetchall()
        return lists
    except:
        print "error"
        return  ([])
